CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    PRIMARY KEY (Time, Username)
    --know which doctor is available
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    userName varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (UserName)
);

CREATE TABLE Appointments (
    AppointmentID INT IDENTITY (1, 1) UNIQUE,
    CareUserName varchar(255) REFERENCES Caregivers(Username),
    PatientUserName varchar(255) REFERENCES Patients(userName),
    VaccineName varchar(255) REFERENCES Vaccines(Name),
    Time date,
    PRIMARY KEY(PatientUserName, Time)
)