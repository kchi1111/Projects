package scheduler;

import scheduler.db.ConnectionManager;
import scheduler.model.Caregiver;
import scheduler.model.Patient;
import scheduler.model.Vaccine;
import scheduler.util.Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

public class Scheduler {

    // objects to keep track of the currently logged-in user
    // Note: it is always true that at most one of currentCaregiver and currentPatient is not null
    //       since only one user can be logged-in at a time
    private static Caregiver currentCaregiver = null;
    private static Patient currentPatient = null;

    public static void main(String[] args) {
        // printing greetings text
        System.out.println();
        System.out.println("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!");
        System.out.println("*** Please enter one of the following commands ***");
        System.out.println("> create_patient <username> <password>");  //TODO: implement create_patient (Part 1)
        System.out.println("> create_caregiver <username> <password>");
        System.out.println("> login_patient <username> <password>");  // TODO: implement login_patient (Part 1)
        System.out.println("> login_caregiver <username> <password>");
        System.out.println("> search_caregiver_schedule <date>");  // TODO: implement search_caregiver_schedule (Part 2)
        System.out.println("> reserve <date> <vaccine>");  // TODO: implement reserve (Part 2)
        System.out.println("> upload_availability <date>");
        System.out.println("> cancel <appointment_id>");  // TODO: implement cancel (extra credit)
        System.out.println("> add_doses <vaccine> <number>");
        System.out.println("> show_appointments");  // TODO: implement show_appointments (Part 2)
        System.out.println("> logout");  // TODO: implement logout (Part 2)
        System.out.println("> quit");
        System.out.println();

        // read input from user
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.print("> ");
            String response = "";
            try {
                response = r.readLine();
            } catch (IOException e) {
                System.out.println("Please try again!");
            }
            // split the user input by spaces
            String[] tokens = response.split(" ");
            // check if input exists
            if (tokens.length == 0) {
                System.out.println("Please try again!");
                continue;
            }
            // determine which operation to perform
            String operation = tokens[0];
            if (operation.equals("create_patient")) {
                createPatient(tokens);
            } else if (operation.equals("create_caregiver")) {
                createCaregiver(tokens);
            } else if (operation.equals("login_patient")) {
                loginPatient(tokens);
            } else if (operation.equals("login_caregiver")) {
                loginCaregiver(tokens);
            } else if (operation.equals("search_caregiver_schedule")) {
                searchCaregiverSchedule(tokens);
            } else if (operation.equals("reserve")) {
                reserve(tokens);
            } else if (operation.equals("upload_availability")) {
                uploadAvailability(tokens);
            } else if (operation.equals("cancel")) {
                cancel(tokens);
            } else if (operation.equals("add_doses")) {
                addDoses(tokens);
            } else if (operation.equals("show_appointments")) {
                showAppointments();
            } else if (operation.equals("logout")) {
                logout();
            } else if (operation.equals("quit")) {
                System.out.println("Bye!");
                return;
            } else {
                System.out.println("Invalid operation name!");
            }
        }
    }

    private static void createPatient(String[] tokens) {
        //check: the length for tokens
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String userName = tokens[1];
        String password = tokens[2];

        if(userNameExistsPatient(userName)) {
            System.out.println("UserName taken, try again!");
            return;
        }

        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);

        try {
            currentPatient = new Patient.PatientBuilder(userName, salt, hash).build();
            currentPatient.saveToDB();
            System.out.println(" *** Account created successfully *** ");
        } catch (SQLException e) {
            System.out.println("Create failed");
            e.printStackTrace();
        }

    }

    private static boolean userNameExistsPatient(String userName) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Patients WHERE UserName = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, userName);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Error occurred when checking username");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void createCaregiver(String[] tokens) {
        // create_caregiver <username> <password>
        // check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];
        // check 2: check if the username has been taken already
        if (usernameExistsCaregiver(username)) {
            System.out.println("Username taken, try again!");
            return;
        }
        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);
        // create the caregiver
        try {
            currentCaregiver = new Caregiver.CaregiverBuilder(username, salt, hash).build();
            // save to caregiver information to our database
            currentCaregiver.saveToDB();
            System.out.println(" *** Account created successfully *** ");
        } catch (SQLException e) {
            System.out.println("Create failed");
            e.printStackTrace();
        }
    }

    private static boolean usernameExistsCaregiver(String username) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Caregivers WHERE Username = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            // returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Error occurred when checking username");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void loginPatient(String[] tokens) {
        if (currentPatient != null || currentCaregiver != null) {
            System.out.println("Already logged-in! ");
            return;
        }
        if (tokens.length != 3) {
            System.out.println("Please try again! ");
            return;
        }
        String userName = tokens[1];
        String password = tokens[2];

        Patient patient = null;
        try {
            patient = new Patient.PatientGetter(userName, password).get();
        } catch (SQLException e) {
            System.out.println("Error occurred when logging in");
            e.printStackTrace();
        }
        if (patient == null) {
            System.out.println("Please try again!");
        } else {
            System.out.println("Patient logged in as: " + userName);
            currentPatient = patient;
        }
    }

    private static void loginCaregiver(String[] tokens) {
        // login_caregiver <username> <password>
        // check 1: if someone's already logged-in, they need to log out first
        if (currentCaregiver != null || currentPatient != null) {
            System.out.println("Already logged-in!");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];

        Caregiver caregiver = null;
        try {
            caregiver = new Caregiver.CaregiverGetter(username, password).get();
        } catch (SQLException e) {
            System.out.println("Error occurred when logging in");
            e.printStackTrace();
        }
        // check if the login was successful
        if (caregiver == null) {
            System.out.println("Please try again!");
        } else {
            System.out.println("Caregiver logged in as: " + username);
            currentCaregiver = caregiver;
        }
    }

    private static void searchCaregiverSchedule(String[] tokens) {
        //both patients + caregivers
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first to search schedule!");
            return;
        }

        //check length of tokens
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }
        //check invalid date
        String date = tokens[1];

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String availCareN = "SELECT Username FROM Availabilities WHERE Time = ?;";
        String allVaccine = "SELECT Name, Doses FROM Vaccines;";

        try {
            Date d = Date.valueOf(date);
            PreparedStatement statement1 = con.prepareStatement(availCareN);
            PreparedStatement statement2 = con.prepareStatement(allVaccine);
            statement1.setDate(1, d);
            ResultSet careName = statement1.executeQuery();
            ResultSet vaccineT = statement2.executeQuery();

            System.out.println("Available Caregiver(s) for this date: ");
            List<String> careN = new ArrayList<String>();
            while (careName.next()) {
                String name = careName.getString("Username");
                careN.add(name);
                System.out.println("    " + name);
            }

            if (careN.size() == 0) {
                System.out.println("    None");
                System.out.println("please try another date!");
                return;
            }

            while (vaccineT.next()) {
                System.out.println("Vaccine Name: " + vaccineT.getString("Name"));
                System.out.println("Amounts left: " + vaccineT.getInt("Doses"));
            }

        } catch (IllegalArgumentException e) {
            System.out.println("Please enter a valid date using the format yyyy-mm-dd");
        } catch (SQLException e) {
            System.out.println("Error occurred when searching");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
    }

    private static void reserve(String[] tokens) {
        //check only patient can perform
        if (currentPatient == null) {
            System.out.println("Please login as a patient first!");
            return;
        }
        //check length of tokens
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String date = tokens[1];
        String vaccineName = tokens[2];

        String availCareN = "SELECT Username FROM Availabilities WHERE Time = ?;";
        String deleteName = "DELETE FROM Availabilities WHERE Username = ?;";
        String addingAppointment = "INSERT Appointments (CareUserName, PatientUserName, VaccineName, Time) VALUES (?, ?, ?, ?);";
        String getID = "SELECT AppointmentID FROM Appointments WHERE PatientUserName = ? AND Time = ?;";
        String checkReserved = "SELECT PatientUsername FROM Appointments WHERE PatientUserName = ? AND Time = ?;";
        try {
            Date d = Date.valueOf(date);
            //check if already reserved on the same day
            PreparedStatement statement = con.prepareStatement(checkReserved);
            statement.setString(1, currentPatient.getUserName());
            statement.setDate(2, d);
            ResultSet checkR = statement.executeQuery();
            while (checkR.next()) {
                if (!checkR.wasNull()) {
                    System.out.println("Already reserved for this date!");
                    return;
                }
            }

            //check avail caregivers
            PreparedStatement statement1 = con.prepareStatement(availCareN);
            statement1.setDate(1, d);
            ResultSet careName = statement1.executeQuery();
            List<String> careN = new ArrayList<String>();
            while (careName.next()) {
                careN.add(careName.getString("Username"));
            }
            //no caregiver available that day
            if (careN.size() == 0) {
                System.out.println("No available caregivers at this date, please try another date!");
                return;
            }

            //No vaccine avail:
            Vaccine vaccine = new Vaccine.VaccineGetter(vaccineName).get();
            if (vaccine == null) {
                System.out.println("No vaccine available");
                System.out.println("Please reserve for a different vaccine brand!");
                return;
            }

            //Vaccine Number - 1
            int doses = 1;
            vaccine.decreaseAvailableDoses(doses);

            //random choosing
            Random rand = new Random();
            int position = rand.nextInt(careN.size());
            String nameChosen = careN.get(position);

            //deleting
            PreparedStatement deleteN = con.prepareStatement(deleteName);
            deleteN.setString(1, nameChosen);
            deleteN.executeUpdate();

            //Insert information into appointments
            PreparedStatement adding = con.prepareStatement(addingAppointment);
            adding.setString(1, nameChosen);
            adding.setString(2, currentPatient.getUserName());
            adding.setString(3, vaccineName);
            adding.setDate(4, d);
            adding.executeUpdate();

            //Appointment ID
            PreparedStatement getting = con.prepareStatement(getID);
            getting.setString(1, currentPatient.getUserName());
            getting.setDate(2, d);
            ResultSet getAID = getting.executeQuery();
            int appID = 0;
            while (getAID.next()){
                appID = getAID.getInt("AppointmentID");
            }

            //Successfully
            System.out.println(" *** Successfully make an appointment *** ");
            System.out.println("    Assigned caregiver: " + nameChosen);
            System.out.println("    Appointment ID: " + appID);
        }  catch (IllegalArgumentException e) {
            System.out.println("Please enter a valid date using the format yyyy-mm-dd");
        } catch (SQLException e) {
            System.out.println("Error occurred when reserving");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
    }

    private static void uploadAvailability(String[] tokens) {
        // upload_availability <date>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }
        String date = tokens[1];
        try {
            Date d = Date.valueOf(date);
            currentCaregiver.uploadAvailability(d);
            System.out.println("Availability uploaded!");
        } catch (IllegalArgumentException e) {
            System.out.println("Please enter a valid date!");
        } catch (SQLException e) {
            System.out.println("Error occurred when uploading availability");
            e.printStackTrace();
        }
    }

    private static void cancel(String[] tokens) {
        //both patients + caregivers
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first!");
            return;
        }

        //check length of tokens
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }

        String appointmentID = tokens[1];

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String addAvail = "INSERT INTO Availabilities (Time, Username) SELECT Time, CareUserName FROM Appointments WHERE AppointmentID = ?;";
        String vaccineN = "SELECT VaccineName FROM Appointments WHERE AppointmentID = ?;";
        String deleting = "DELETE FROM Appointments WHERE AppointmentID = ?;";

        try {
            //add availability back
            PreparedStatement add = con.prepareStatement(addAvail);
            add.setString(1, appointmentID);
            add.executeUpdate();

            //Vaccine + 1
            PreparedStatement vaccN = con.prepareStatement(vaccineN);
            vaccN.setString(1, appointmentID);
            ResultSet resultSet = vaccN.executeQuery();
            String vaccineName = null;
            while (resultSet.next()) {
                vaccineName = resultSet.getString("VaccineName");
            }
            Vaccine vaccine = new Vaccine.VaccineGetter(vaccineName).get();
            int doses = 1;
            vaccine.increaseAvailableDoses(doses);

            //delete from Appointments Table
            PreparedStatement delete = con.prepareStatement(deleting);
            delete.setString(1, appointmentID);
            delete.executeUpdate();

            System.out.println(" *** Successfully cancel the appointment *** ");
        }  catch (IllegalArgumentException e) {
            System.out.println("Error occurred when cancelling");
        } catch (SQLException e) {
            System.out.println("Error occurred when cancelling");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
    }

    private static void addDoses(String[] tokens) {
        // add_doses <vaccine> <number>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String vaccineName = tokens[1];
        int doses = Integer.parseInt(tokens[2]);
        Vaccine vaccine = null;
        try {
            vaccine = new Vaccine.VaccineGetter(vaccineName).get();
        } catch (SQLException e) {
            System.out.println("Error occurred when adding doses");
            e.printStackTrace();
        }
        // check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
        //          table
        if (vaccine == null) {
            try {
                vaccine = new Vaccine.VaccineBuilder(vaccineName, doses).build();
                vaccine.saveToDB();
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        } else {
            // if the vaccine is not null, meaning that the vaccine already exists in our table
            try {
                vaccine.increaseAvailableDoses(doses);
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        }
        System.out.println("Doses updated!");
    }

    private static void showAppointments() {
        //check login
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first!");
            return;
        }

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String showCaregiverA = "SELECT * FROM Appointments WHERE CareUserName = ?;";
        String showPatientA = "SELECT * FROM Appointments WHERE PatientUserName = ?;";

        try {
            System.out.println("Appointment(s) shown below:");
            if (currentCaregiver != null) {
                //caregiver login
                PreparedStatement statement1 = con.prepareStatement(showCaregiverA);
                statement1.setString(1, currentCaregiver.getUsername());
                ResultSet resultSet = statement1.executeQuery();
                while (resultSet.next()) {
                    System.out.println("    Appointment ID: " + resultSet.getString("AppointmentID"));
                    System.out.println("    Vaccine Name: " + resultSet.getString("VaccineName"));
                    System.out.println("    Date: " + resultSet.getDate("Time"));
                    System.out.println("    Patient Username: " + resultSet.getString("PatientUserName"));
                }
            } else {
                //patient login
                PreparedStatement statement2 = con.prepareStatement(showPatientA);
                statement2.setString(1, currentPatient.getUserName());
                ResultSet resultSet2 = statement2.executeQuery();
                while (resultSet2.next()) {
                    System.out.println("    Appointment ID: " + resultSet2.getString("AppointmentID"));
                    System.out.println("    Vaccine Name: " + resultSet2.getString("VaccineName"));
                    System.out.println("    Date: " + resultSet2.getDate("Time"));
                    System.out.println("    Caregiver Username: " + resultSet2.getString("CareUserName"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error occurred when showing availability");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
    }

    private static void logout() {
        //check if no one login
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first to logout!");
            return;
        }
        //logout
        if (currentPatient != null) {
            currentPatient = null;
        } else {
            currentCaregiver = null;
        }
        System.out.println(" *** Logout successfully *** ");
    }
}
